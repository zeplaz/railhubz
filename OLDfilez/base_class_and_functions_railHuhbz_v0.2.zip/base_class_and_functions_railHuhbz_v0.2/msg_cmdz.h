#ifndef MSG_TYPEZ
#define MSG_TYPEZ


enum msg_cmdz{enter_line, exit_line,report_status,halt_cmd,move_cmd};


#endif
